package com.smiley.ai

import android.animation.ObjectAnimator
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.view.animation.LinearInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class FloatingService : Service(), TextToSpeech.OnInitListener {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var ball: ImageView
    private lateinit var panel: LinearLayout
    private lateinit var input: EditText
    private var bubble: TextView? = null
    private var tts: TextToSpeech? = null
    private var panelShown = false
    private var mouthOpen = false
    private var talking = false
    private val hist = JSONArray()
    private val persona = "You are Smiley, a cheerful, warm, playful floating ball friend on the person's phone screen. Reply in the same language the person uses, in 1-2 short spoken-style sentences, no markdown, no emojis."

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("smiley", "Smiley", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "smiley").setContentTitle("Smiley is floating").setSmallIcon(R.drawable.smiley_closed).build())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        buildBall(); buildPanel()
    }

    override fun onInit(s: Int) {
        tts?.language = Locale.getDefault(); tts?.setPitch(1.3f); tts?.setSpeechRate(1.05f)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { ui.post { talking = true; mouth() } }
            override fun onDone(id: String?) { ui.post { stopTalk() } }
            @Deprecated("x") override fun onError(id: String?) { ui.post { stopTalk() } }
        })
    }

    private fun mouth() {
        if (!talking) return
        mouthOpen = !mouthOpen
        ball.setImageResource(if (mouthOpen) R.drawable.smiley_open else R.drawable.smiley_closed)
        ui.postDelayed({ mouth() }, 170)
    }
    private fun stopTalk() { talking = false; ball.setImageResource(R.drawable.smiley_closed); ui.postDelayed({ hideBubble() }, 2500) }

    private fun buildBall() {
        root = FrameLayout(this).apply { setPadding(dp(12), dp(12), dp(12), dp(12)) }
        ball = ImageView(this).apply { setImageResource(R.drawable.smiley_closed) }
        root.addView(ball, FrameLayout.LayoutParams(dp(60), dp(60)))
        val badge = TextView(this).apply {
            text = "\uD83D\uDCAC"; textSize = 13f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#4A5FF0")) }
        }
        root.addView(badge, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.END))
        ObjectAnimator.ofFloat(ball, "translationY", -dp(5).toFloat(), dp(5).toFloat()).apply {
            duration = 1600; repeatMode = ObjectAnimator.REVERSE; repeatCount = ObjectAnimator.INFINITE; start()
        }
        val lp = WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(300) }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - tx) > 12 || Math.abs(e.rawY - ty) > 12) moved = true
                    if (moved) { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(root, lp)
    }

    private fun buildPanel() {
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply { setColor(Color.parseColor("#E61B2140")); cornerRadius = dp(24).toFloat() }
        }
        input = EditText(this).apply {
            hint = "Ask Smiley..."; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE); setSingleLine()
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> send(); true }
        }
        panel.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(Button(this).apply { text = "\uD83C\uDFA4"; setOnClickListener { listen() } })
        panel.addView(Button(this).apply { text = "\u27A4"; setOnClickListener { send() } })
    }

    private fun togglePanel() {
        if (panelShown) { wm.removeView(panel); panelShown = false; return }
        val lp = WindowManager.LayoutParams(-1, -2, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.BOTTOM; softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE; y = dp(8) }
        wm.addView(panel, lp); panelShown = true
        input.requestFocus()
        input.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) }, 200)
    }

    private fun send() {
        val q = input.text.toString().trim(); if (q.isEmpty()) return
        input.setText(""); if (panelShown) togglePanel(); ask(q)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { show("Speech input isn't available, please type"); return }
        if (panelShown) togglePanel()
        show("I'm listening...")
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) { r.destroy(); b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { ask(it) } }
            override fun onError(e: Int) { r.destroy(); show("I didn't hear you, try again") }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}; override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
    }

    private fun ask(q: String) {
        show("Hmm...")
        hist.put(JSONObject().put("role", "user").put("content", q))
        Thread {
            val ans = try {
                val key = getSharedPreferences("smiley", MODE_PRIVATE).getString("key", "") ?: ""
                val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 200).put("system", persona).put("messages", hist)
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("content-type", "application/json"); c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val s = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
                val j = JSONObject(s)
                if (j.has("error")) throw Exception(j.getJSONObject("error").getString("message"))
                j.getJSONArray("content").getJSONObject(0).getString("text").trim()
            } catch (e: Exception) { "Oops, I can't think right now. Check your key and internet." }
            ui.post {
                hist.put(JSONObject().put("role", "assistant").put("content", ans))
                while (hist.length() > 12) hist.remove(0)
                show(ans); tts?.speak(ans, TextToSpeech.QUEUE_FLUSH, null, "s")
            }
        }.start()
    }

    private fun show(t: String) {
        hideBubble()
        bubble = TextView(this).apply {
            text = t; setTextColor(Color.BLACK); textSize = 15f; maxWidth = dp(280); setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(18).toFloat() }
        }
        wm.addView(bubble, WindowManager.LayoutParams(-2, -2, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(80) })
        if (!talking) ui.postDelayed({ hideBubble() }, 4000)
    }
    private fun hideBubble() { bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null }

    override fun onDestroy() {
        hideBubble(); try { wm.removeView(root) } catch (_: Exception) {}
        if (panelShown) try { wm.removeView(panel) } catch (_: Exception) {}
        tts?.shutdown(); super.onDestroy()
    }
}
