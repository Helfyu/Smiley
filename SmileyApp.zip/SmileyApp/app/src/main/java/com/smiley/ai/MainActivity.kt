package com.smiley.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("smiley", MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(pad, pad, pad, pad) }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.smiley_closed); layoutParams = LinearLayout.LayoutParams(pad * 5, pad * 5) })
        col.addView(TextView(this).apply { text = "Smiley – your floating AI friend"; textSize = 20f; gravity = Gravity.CENTER })
        val key = EditText(this).apply { hint = "Paste your Anthropic API key (sk-ant-...)"; setText(p.getString("key", "")); setSingleLine() }
        col.addView(key, LinearLayout.LayoutParams(-1, -2))
        col.addView(Button(this).apply {
            text = "Start Smiley"
            setOnClickListener {
                p.edit().putString("key", key.text.toString().trim()).apply()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(context, "Allow 'Display over other apps', then press Start again", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                    startForegroundService(Intent(this@MainActivity, FloatingService::class.java))
                    finish()
                }
            }
        })
        col.addView(Button(this).apply { text = "Stop Smiley"; setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)) } })
        setContentView(col)
    }
}
